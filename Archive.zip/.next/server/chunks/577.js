"use strict";
exports.id = 577;
exports.ids = [577];
exports.modules = {

/***/ 7422:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ components_Project)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "@react-three/fiber"
var fiber_ = __webpack_require__(3784);
// EXTERNAL MODULE: external "@react-three/drei"
var drei_ = __webpack_require__(4165);
// EXTERNAL MODULE: external "react-device-detect"
var external_react_device_detect_ = __webpack_require__(3599);
// EXTERNAL MODULE: external "three"
var external_three_ = __webpack_require__(2248);
;// CONCATENATED MODULE: ./components/Phone.jsx





function Model({ ProjectRef , pid  }) {
    const group = (0,external_react_.useRef)();
    const { nodes , materials  } = new drei_.useGLTF("/iphone.gltf");
    materials.Frame.color = {
        r: 0,
        g: 0,
        b: 0
    };
    // const texture = new THREE.TextureLoader().load(`./project/${pid}.png`);
    const materialScreen = materials.Screen.clone();
    materialScreen.map = materialScreen.map.clone();
    let img = new Image();
    img.src = `./project/${pid}.png`;
    materialScreen.map.image = img;
    materialScreen.map.needsUpdate = true;
    (0,external_react_.useEffect)(()=>{
        ProjectRef.current.addEventListener("mousemove", rotatModel);
    }, []);
    const rotatModel = (e)=>{
        const target = e.target;
        const rect = target.getBoundingClientRect();
        const x = e.clientX - rect.left;
        let windowWidth = ProjectRef.current.clientWidth / 2;
        group.current.rotation.y = (x % (2 * windowWidth) - windowWidth) / windowWidth;
    };
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("group", {
        scale: [
            1.2,
            1.2,
            1.2
        ],
        ref: group,
        dispose: null,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("mesh", {
                geometry: nodes.Frame.geometry,
                material: materials.Frame
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("mesh", {
                geometry: nodes.Screen.geometry,
                material: materialScreen
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("mesh", {
                geometry: nodes.Logo.geometry,
                material: materials.Logo
            })
        ]
    }));
}
drei_.useGLTF.preload("/iphone.gltf");
const Lights = ()=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("ambientLight", {
                intensity: 1
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("directionalLight", {
                position: [
                    0,
                    0,
                    -5
                ],
                intensity: 1
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("directionalLight", {
                position: [
                    -10,
                    0,
                    2
                ],
                intensity: 1.5
            })
        ]
    }));
};
const Phone = ({ ProjectRef , pid  })=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(fiber_.Canvas, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Lights, {
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(external_react_.Suspense, {
                fallback: null,
                children: /*#__PURE__*/ jsx_runtime_.jsx(Model, {
                    ProjectRef: ProjectRef,
                    pid: pid
                })
            })
        ]
    }));
};
/* harmony default export */ const components_Phone = (Phone);

;// CONCATENATED MODULE: ./components/Laptop.jsx





function Laptop_Model({ ProjectRef , pid  }) {
    const group = (0,external_react_.useRef)();
    const { nodes , materials  } = (0,drei_.useGLTF)("/browser.gltf");
    (0,external_react_.useEffect)(()=>{
        ProjectRef.current.addEventListener("mousemove", rotatModel);
    }, []);
    const rotatModel = (e)=>{
        const target = e.target;
        const rect = target.getBoundingClientRect();
        const x = e.clientX - rect.left;
        let windowWidth = ProjectRef.current.clientWidth / 2;
        group.current.rotation.y = (x % (2 * windowWidth) - windowWidth) / windowWidth * 0.8;
    };
    materials["Frame.001"].color = {
        r: 0,
        g: 0,
        b: 0
    };
    materials.Buttons.color = {
        r: 0,
        g: 0,
        b: 0
    };
    const materialScreen = materials["Screen.001"].clone();
    materialScreen.map = materials["Screen.001"].map.clone();
    let img = new Image();
    img.src = `./project/${pid}.png`;
    materialScreen.map.image = img;
    materialScreen.map.needsUpdate = true;
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("group", {
        scale: [
            1.8,
            1.8,
            1.8
        ],
        ref: group,
        dispose: null,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("mesh", {
                geometry: nodes.Frame.geometry,
                material: materials["Frame.001"],
                rotation: [
                    Math.PI / 2,
                    0,
                    0
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("mesh", {
                geometry: nodes.Screen.geometry,
                material: materialScreen,
                rotation: [
                    Math.PI / 2,
                    0,
                    0
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("mesh", {
                geometry: nodes.Buttons.geometry,
                material: materials.Buttons,
                rotation: [
                    Math.PI / 2,
                    0,
                    0
                ]
            })
        ]
    }));
}
drei_.useGLTF.preload("/browser.gltf");
const Laptop_Lights = ()=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("ambientLight", {
                intensity: 1
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("directionalLight", {
                position: [
                    0,
                    0,
                    -5
                ],
                intensity: 1
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("directionalLight", {
                position: [
                    -10,
                    0,
                    2
                ],
                intensity: 1.5
            })
        ]
    }));
};
const Laptop = ({ ProjectRef , pid  })=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(fiber_.Canvas, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Laptop_Lights, {
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(external_react_.Suspense, {
                fallback: null,
                children: /*#__PURE__*/ jsx_runtime_.jsx(Laptop_Model, {
                    ProjectRef: ProjectRef,
                    pid: pid
                })
            })
        ]
    }));
};
/* harmony default export */ const components_Laptop = (Laptop);

// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: external "framer-motion"
var external_framer_motion_ = __webpack_require__(9034);
;// CONCATENATED MODULE: ./components/Project.jsx









const Project = ({ isMob =false , pid , view =true  })=>{
    const ProjectRef = (0,external_react_.useRef)(null);
    const refItem = (0,external_react_.useRef)(null);
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_framer_motion_.motion.div, {
        ref: ProjectRef,
        // layoutId={`container-${pid}`}
        className: "Container__ProjectModel_reveal Container__ProjectModel cursor-pointer relative h-full w-full",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "relative w-full h-full overflow-hidden",
                children: /*#__PURE__*/ jsx_runtime_.jsx(external_framer_motion_.motion.div, {
                    className: "absolute top-0 left-0 h-screen w-screen overflow-hidden",
                    layoutId: `image-${pid}`,
                    transition: {
                        duration: 1,
                        delay: 0.15
                    },
                    children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                        className: "object-cover h-full",
                        src: `./project/${pid}_thumbnail.png`,
                        alt: "",
                        draggable: false
                    })
                })
            }),
            !external_react_device_detect_.isMobile && view ? /*#__PURE__*/ jsx_runtime_.jsx("div", {
                ref: refItem,
                className: "opacity-0 absolute top-1/2 left-1/2 transform -translate-y-1/2 -translate-x-1/2 ProjectModel",
                children: isMob ? /*#__PURE__*/ jsx_runtime_.jsx(components_Phone, {
                    ProjectRef: ProjectRef,
                    pid: pid
                }, pid) : /*#__PURE__*/ jsx_runtime_.jsx(components_Laptop, {
                    ProjectRef: ProjectRef,
                    pid: pid
                })
            }) : null
        ]
    }));
};
/* harmony default export */ const components_Project = (Project);


/***/ }),

/***/ 1577:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ work)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./components/Project.jsx + 2 modules
var Project = __webpack_require__(7422);
// EXTERNAL MODULE: external "framer-motion"
var external_framer_motion_ = __webpack_require__(9034);
// EXTERNAL MODULE: ./components/Loader.jsx
var Loader = __webpack_require__(8565);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: ./assets/ScrollArrow.svg
var ScrollArrow = __webpack_require__(465);
var ScrollArrow_default = /*#__PURE__*/__webpack_require__.n(ScrollArrow);
;// CONCATENATED MODULE: ./components/ProjectData.json
const ProjectData_namespaceObject = JSON.parse('[{"pid":"stonks","title":"Paper Trading","category":"UI/UX","description":"A concept paper trading app with simple and minimal user interface.","isMob":true,"link":"https://dribbble.com/shots/15689909-Concept-Paper-Trading-App"},{"pid":"calorifit","title":"Calorifit","category":"WebDev","description":"A simple calorie tracker built on react, made for simplicity and to showcase minimal User Interface in a project.","isMob":true,"link":"https://calorifit.netlify.app/"},{"pid":"audi_bike","title":"E-bike Page","category":"UI/UX","description":"An concept landing page based on a 3d e-bike model by Ashok Yeli.","isMob":false,"link":"https://dribbble.com/shots/15847382-Audi-E-bike-Landing-Page"},{"pid":"1mm","title":"Brand Landing Page","category":"website","description":"A brand landing page with minimal UI and smooth scroll effects and animations.","isMob":false,"link":"https://brandweb.vercel.app/"},{"pid":"shop","title":"e-shop concept","category":"UI/UX","description":"UI design for a e-commerce concept app based on light theme and soft shadows.","isMob":true,"link":"https://twitter.com/techakhil_me/status/1458822788819554306?s=20"},{"pid":"linkedindark","title":"linkedin dark mode","category":"UI/UX","description":"Just my view on how linkedin should work on their dark mode feature. Don\'t know why it did took so long for linkedin to roll dark theme.","isMob":true,"link":"https://dribbble.com/shots/16145790-Linkedin-Dark-mode-concept"},{"pid":"spotifyclone","title":"spotify clone","category":"website","description":"An attempt to clone spotify using django and complete backend based on python. This is one of my early projects and I admire them till date.","isMob":false,"link":"https://youttify.pythonanywhere.com/demo/"},{"pid":"gaveit","title":"gaveit","category":"website","description":"An e-commerce project made as a part of a hackathon event, uses express apis and react-tailwind based frontend. To be honest, it was an attempt to redesign amazon.","isMob":false,"link":"https://gaveit.vercel.app/"}]');
;// CONCATENATED MODULE: ./components/Item.jsx








function Item({ id  }) {
    const { asPath  } = (0,router_.useRouter)();
    const { category , title , pid , description , link , isMob  } = ProjectData_namespaceObject.find((item)=>item.pid === id
    );
    return(/*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_framer_motion_.motion.div, {
            initial: {
                opacity: 0
            },
            animate: {
                opacity: 1,
                transition: {
                    duration: 1
                }
            },
            exit: {
                opacity: 0,
                transition: {
                    duration: 1
                }
            },
            transition: {
                delay: 0.15
            },
            style: {
                pointerEvents: "auto"
            },
            className: "fixed bg-dark flex items-center flex-col md:flex-row md:px-4 container w-screen h-full md:h-screen z-50 transform top-0 left-1/2 -translate-x-1/2",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_framer_motion_.motion.div, {
                    className: "mt-12 mb-6 md:mb-0 md:mt-0 w-full h-full inline-flex flex-col space-y-0 md:space-y-2 items-center justify-center text-center",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "fixed top-4 left-0 ",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                href: asPath.split("?")[0],
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                    className: "cursor-pointer flex items-center",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "transform rotate-90",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((ScrollArrow_default()), {
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            href: "/about",
                                            className: "text-sm font-medium tracking-widest leading-snug text-gray-100 uppercase",
                                            children: "explore other projects"
                                        })
                                    ]
                                })
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "text-2xl md:text-4xl font-bold tracking-widest leading-10 uppercase text-stroke",
                            children: category
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "text-4xl md:text-7xl font-bold tracking-widest uppercase",
                            children: title
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "text-base leading-loose text-center p-10",
                            children: description
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            href: link,
                            target: "_blank",
                            className: "px-8 py-5 bg-gray-100 rounded-full text-xs tracking-widest leading-none text-center text-dark uppercase",
                            children: "See more"
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(external_framer_motion_.motion.div, {
                    className: "w-full h-full flex items-center",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(Project/* default */.Z, {
                        pid: pid,
                        isMob: isMob,
                        view: false
                    })
                })
            ]
        })
    }));
};

;// CONCATENATED MODULE: ./components/List.jsx







function Card({ pid , isMob  }) {
    const { asPath  } = (0,router_.useRouter)();
    return(/*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
        href: `${asPath}?pid=` + pid,
        children: /*#__PURE__*/ jsx_runtime_.jsx("li", {
            className: "card",
            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                children: /*#__PURE__*/ jsx_runtime_.jsx(Project/* default */.Z, {
                    pid: pid,
                    isMob: isMob,
                    thumbnail: `./project/${pid}_thumbnail.png`
                })
            })
        })
    }));
}
function List({ isComponent  }) {
    const variants = {
        hidden: {
            opacity: 0
        },
        enter: {
            opacity: 1,
            x: 0,
            y: 0,
            transition: {
                staggerChildren: 0.5,
                ease: "easeInOut",
                duration: 2
            }
        },
        exit: {
            opacity: 0,
            x: 0,
            y: -100,
            transition: {
                staggerChildren: 0.5
            }
        }
    };
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_framer_motion_.motion.ul, {
        "data-scroll-section": true,
        className: "flex flex-wrap",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(external_framer_motion_.motion.div, {
                className: "card",
                children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                    className: "grid text-center place-content-center h-full text-2xl font-medium tracking-widest leading-tight text-light uppercase",
                    children: "PROMINENT WORKS"
                })
            }),
            isComponent ? ProjectData_namespaceObject.slice(0, 4).map((card)=>/*#__PURE__*/ jsx_runtime_.jsx(Card, {
                    ...card
                }, card.pid)
            ) : ProjectData_namespaceObject.map((card)=>/*#__PURE__*/ jsx_runtime_.jsx(Card, {
                    ...card
                }, card.pid)
            ),
            isComponent ? /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "card",
                children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                    className: "grid text-center place-content-center h-full text-2xl font-medium tracking-widest leading-tight text-light uppercase",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                        href: "#",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            className: "px-8 py-5 bg-gray-100 rounded-full text-xs tracking-widest leading-none text-center text-dark uppercase",
                            children: "See more"
                        })
                    })
                })
            }) : /*#__PURE__*/ jsx_runtime_.jsx(external_framer_motion_.motion.div, {
                className: "card",
                children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                    className: "grid text-center place-content-center h-full text-2xl font-medium tracking-widest leading-tight text-light uppercase",
                    children: "More Soon"
                })
            })
        ]
    }));
};

;// CONCATENATED MODULE: ./pages/work/index.jsx








const WorkPage = ({ isComponent =false  })=>{
    const { 0: Loading , 1: setLoading  } = (0,external_react_.useState)(true);
    const { 0: ProjectId , 1: setProjectId  } = (0,external_react_.useState)(false);
    const controls = (0,external_framer_motion_.useAnimation)();
    const router = (0,router_.useRouter)();
    const variants = {
        hidden: {
            opacity: 0
        },
        enter: {
            opacity: 1,
            x: 0,
            y: 0,
            transition: {
                staggerChildren: 0.5,
                ease: "easeInOut",
                duration: 2
            }
        },
        exit: {
            opacity: 0,
            x: 0,
            y: -100,
            transition: {
                staggerChildren: 0.5
            }
        }
    };
    (0,external_react_.useEffect)(()=>{
        if (!Loading) {
            controls.start("enter");
        } else {
            setTimeout(()=>{
                setLoading(false);
            }, 3000);
            controls.start("hidden");
        }
    }, [
        Loading,
        controls
    ]);
    (0,external_react_.useEffect)(()=>{
        const { pid  } = router.query;
        if (pid) {
            setProjectId(pid);
        } else setProjectId(false);
    }, [
        router
    ]);
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            isComponent ? null : /*#__PURE__*/ jsx_runtime_.jsx(external_framer_motion_.AnimatePresence, {
                exitBeforeEnter: true,
                initial: false,
                children: Loading ? /*#__PURE__*/ jsx_runtime_.jsx(Loader/* default */.Z, {
                }) : null
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(external_framer_motion_.motion.div, {
                variants: variants,
                initial: "hidden",
                animate: controls,
                exit: "exit",
                className: "w-full",
                className: "opacity-1 transition duration-2000",
                children: /*#__PURE__*/ jsx_runtime_.jsx(List, {
                    isComponent: isComponent,
                    controls: controls
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(external_framer_motion_.AnimatePresence, {
                children: ProjectId && /*#__PURE__*/ jsx_runtime_.jsx(Item, {
                    id: ProjectId
                }, "item")
            })
        ]
    }));
};
/* harmony default export */ const work = (WorkPage);


/***/ })

};
;