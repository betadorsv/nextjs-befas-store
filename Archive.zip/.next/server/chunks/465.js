exports.id = 465;
exports.ids = [465];
exports.modules = {

/***/ 465:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var React = __webpack_require__(6689);

function ScrollArrow (props) {
    return React.createElement("svg",props,[React.createElement("style",{"key":0},"\n  #logo_line{\nanimation: load 10s ease infinite forwards;}\n\n@keyframes load {\n0{\nstroke-dashoffset:0;}\n20%{stroke-dashoffset:-118;}\n100%{stroke-dashoffset:-118;}}"),React.createElement("path",{"id":"logo_line","strokeDasharray":"59","d":"M6 9L12 15L18 9","stroke":"#F7F7F7","strokeWidth":"2","strokeLinecap":"round","strokeLinejoin":"round","key":1})]);
}

ScrollArrow.defaultProps = {"width":"24","height":"24","viewBox":"0 0 24 24","fill":"none"};

module.exports = ScrollArrow;

ScrollArrow.default = ScrollArrow;


/***/ })

};
;