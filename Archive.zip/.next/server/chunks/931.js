"use strict";
exports.id = 931;
exports.ids = [931];
exports.modules = {

/***/ 1931:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ components_Layout)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "framer-motion"
var external_framer_motion_ = __webpack_require__(9034);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: ./components/SocialTray.jsx
var SocialTray = __webpack_require__(1259);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: ./node_modules/next/dist/client/image.js
var client_image = __webpack_require__(8045);
;// CONCATENATED MODULE: ./assets/logo_only_w.png
/* harmony default export */ const logo_only_w = ({"src":"/_next/static/media/logo_only_w.8852b797.png","height":88,"width":363,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAACCAQAAADPnVVmAAAAKklEQVR42mP41/Fv5r/6f4X/6v5N+Jfwr4Thn+O/3n9V/3L+OQNx/r8SAJPZFxrSGWA4AAAAAElFTkSuQmCC"});
;// CONCATENATED MODULE: ./components/Navbar.jsx









const variants = {
    open: {
        opacity: 1,
        transition: {
            duration: 1,
            staggerChildren: 0.1,
            delayChildren: 0.2
        }
    },
    closed: {
        opacity: 0,
        transition: {
            // duration: 0.1,
            staggerChildren: 0.05,
            staggerDirection: -1,
            when: "afterChildren"
        }
    }
};
const childVariants = {
    open: {
        y: 0,
        opacity: 1,
        rotateZ: "0deg",
        transition: {
            stiffness: 1000
        }
    },
    closed: {
        y: 50,
        opacity: 0,
        rotateZ: "5deg",
        transition: {
            stiffness: 200,
            duration: 0.1
        }
    }
};
const Navbar = ()=>{
    const { 0: isOpen , 1: setisOpen  } = (0,external_react_.useState)(false);
    const { 0: page , 1: setPage  } = (0,external_react_.useState)("home");
    const router = (0,router_.useRouter)();
    const defaultNav = {
        home: "inActive",
        about: "inActive",
        contact: "inActive",
        collection: "inActive"
    };
    const { 0: isActive , 1: setActive  } = (0,external_react_.useState)(defaultNav);
    (0,external_react_.useEffect)(()=>{
        let Path = router.asPath.slice(1);
        Path = Path === "" ? "home" : Path;
        setActive({
            ...defaultNav,
            [Path]: "Active"
        });
        setPage(Path);
    }, [
        router
    ]);
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_framer_motion_.motion.nav, {
        variants: variants,
        initial: "hidden",
        animate: "enter",
        exit: "exit",
        exitBeforeEnter: true,
        className: isOpen ? "fixed container pointer-events-none left-1/2 transfrom -translate-x-1/2 md:px-2 px-4 mx-auto text-light  z-20 top-0 transition duration-1000 ease-in-out antialiased w-full py-4 bg-dark" : "fixed container pointer-events-none left-1/2 transfrom -translate-x-1/2 md:px-2 px-4 mx-auto text-light  z-20 top-0 transition duration-1000 ease-in-out antialiased w-full py-4",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("title", {
                        children: page.toUpperCase() + " | BEFAS"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "viewport",
                        content: "width=device-width, initial-scale=1.0"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("link", {
                        rel: "shortcut icon",
                        href: "/logo_only_w.png"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "title",
                        content: "BEFAS"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        property: "og:type",
                        content: "website"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        property: "og:url",
                        content: "https://www.befastm.com/"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        property: "og:title",
                        content: "BEFAS"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        property: "og:site_name",
                        content: "BEFAS"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        property: "og:description",
                        content: "BEFAS"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        property: "og:image",
                        content: "/logo_only_w.png"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "keywords",
                        content: "BEFAS"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex justify-between items-center",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                        className: "md:flex pointer-events-auto hidden items-center space-x-20 text-xs antialiased font-medium tracking-widest",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                    href: "/",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        className: `h-8 flex flex-col justify-center fx-underline ${isActive.home}`,
                                        children: "HOME"
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                    href: "#",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        className: `h-8 flex flex-col justify-center fx-underline ${isActive.collection}`,
                                        children: "COLLECTION"
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                    href: "#",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        className: `h-8 flex flex-col justify-center fx-underline ${isActive.about}`,
                                        children: "ABOUT"
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                    href: "#",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        className: `h-8 flex flex-col justify-center fx-underline ${isActive.contact}`,
                                        children: "CONTACT"
                                    })
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        className: "text-light pointer-events-auto md:hidden w-10 h-10 relative focus:outline-none",
                        onClick: ()=>{
                            setisOpen(!isOpen);
                        },
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "block w-10 absolute left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2 ",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: `block rounded-full absolute h-0.5 w-9 bg-current transform transition duration-1000 ease-in-out ${isOpen ? "-rotate-45" : "-translate-y-2.5"}`
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: `block rounded-full absolute  h-0.5 w-9 bg-current   transform transition duration-1000 ease-in-out ${isOpen ? "-translate-x-10 opacity-0" : ""}`
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: `block rounded-full absolute  h-0.5 w-9 bg-current transform  transition duration-1000 ease-in-out ${isOpen ? "rotate-45" : "translate-y-2.5"}`
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                        href: "/",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            className: "pointer-events-auto",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(client_image["default"], {
                                src: logo_only_w,
                                id: "brand",
                                width: "97",
                                height: "21"
                            })
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(external_framer_motion_.AnimatePresence, {
                initial: false,
                children: isOpen && /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_framer_motion_.motion.ul, {
                    animate: "open",
                    initial: "closed",
                    exit: "closed",
                    variants: variants,
                    className: "flex pointer-events-auto flex-col md:hidden space-y-8 h-screen items-center justify-center text-xl tracking-widest",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(external_framer_motion_.motion.li, {
                            onClick: ()=>{
                                setisOpen(!isOpen);
                            },
                            variants: childVariants,
                            children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                title: "HOME",
                                className: "h-10 text-4xl font-bold flex flex-col justify-center fx-underline",
                                href: "/",
                                children: "HOME"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(external_framer_motion_.motion.li, {
                            onClick: ()=>{
                                setisOpen(!isOpen);
                            },
                            variants: childVariants,
                            children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                className: "h-10 text-4xl font-bold flex flex-col justify-center fx-underline",
                                href: "#",
                                children: "ABOUT"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(external_framer_motion_.motion.li, {
                            onClick: ()=>{
                                setisOpen(!isOpen);
                            },
                            variants: childVariants,
                            children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                className: "h-10 text-4xl font-bold flex flex-col justify-center fx-underline",
                                href: "#",
                                children: "COLECTION"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(external_framer_motion_.motion.li, {
                            onClick: ()=>{
                                setisOpen(!isOpen);
                            },
                            variants: childVariants,
                            children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                className: "h-10 text-4xl font-bold flex flex-col justify-center fx-underline",
                                href: "#",
                                children: "CONTACT"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(external_framer_motion_.motion.div, {
                            onClick: ()=>{
                                setisOpen(!isOpen);
                            },
                            variants: childVariants,
                            children: /*#__PURE__*/ jsx_runtime_.jsx(SocialTray/* default */.Z, {
                            })
                        })
                    ]
                })
            })
        ]
    }));
};
/* harmony default export */ const components_Navbar = (Navbar);

// EXTERNAL MODULE: ./assets/ScrollArrow.svg
var ScrollArrow = __webpack_require__(465);
var ScrollArrow_default = /*#__PURE__*/__webpack_require__.n(ScrollArrow);
// EXTERNAL MODULE: external "typewriter-effect"
var external_typewriter_effect_ = __webpack_require__(2589);
var external_typewriter_effect_default = /*#__PURE__*/__webpack_require__.n(external_typewriter_effect_);
;// CONCATENATED MODULE: ./components/Easter.jsx






const Easter = ({ setEasterEgg , setOnce , Once  })=>{
    const { 0: breakHeart , 1: setBreakHeart  } = (0,external_react_.useState)(false);
    const { 0: showSocial , 1: setShowSocial  } = (0,external_react_.useState)(false);
    (0,external_react_.useEffect)(()=>{
        setTimeout(()=>setBreakHeart(true)
        , 1000);
    }, []);
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_framer_motion_.motion.div, {
        className: "fixed py-4 md:pt-0 top-0 z-50 left-0 w-screen h-screen bg-dark flex flex-col items-center justify-center",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                onClick: ()=>setEasterEgg(false)
                ,
                className: " fixed top-4 left-4 transform rotate-90",
                children: /*#__PURE__*/ jsx_runtime_.jsx((ScrollArrow_default()), {
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(external_framer_motion_.motion.div, {
                className: "pt-6 text-center pb-0 text-2xl md:text-4xl font-bold tracking-widest uppercase",
                children: /*#__PURE__*/ jsx_runtime_.jsx((external_typewriter_effect_default()), {
                    options: {
                        cursor: "",
                        delay: 100
                    },
                    onInit: (typewriter)=>{
                        typewriter.pauseFor(1000).typeString("you shouldn’t have touched it").start();
                    }
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_framer_motion_.motion.div, {
                className: "flex w-full flex-col items-center justify-center",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(external_framer_motion_.motion.span, {
                        className: "z-10",
                        style: breakHeart ? {
                            opacity: breakHeart ? "0" : "1",
                            transition: breakHeart ? "1s ease-in-out" : "inherit"
                        } : null,
                        transition: {
                            duration: 1
                        },
                        layoutId: "heart",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_framer_motion_.motion.svg, {
                            height: "300",
                            viewBox: "0 0 450 412",
                            fill: "none",
                            xmlns: "http://www.w3.org/2000/svg",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("g", {
                                    filter: "url(#filter0_dii_992:132)",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                        fillRule: "evenodd",
                                        clipRule: "evenodd",
                                        d: "M351.867 61.1328C337.063 46.3215 316.98 38 296.038 38C275.097 38 255.014 46.3215 240.209 61.1328L224.996 76.3458L209.783 61.1328C178.95 30.2993 128.959 30.2993 98.1251 61.1328C67.2916 91.9663 67.2916 141.957 98.1251 172.791L113.338 188.004L224.996 299.662L336.654 188.004L351.867 172.791C366.678 157.986 375 137.903 375 116.962C375 96.0204 366.678 75.9372 351.867 61.1328Z",
                                        fill: "url(#paint0_linear_992:132)"
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("defs", {
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("filter", {
                                            id: "filter0_dii_992:132",
                                            x: "0.111763",
                                            y: "0.555882",
                                            width: "449.776",
                                            height: "411.438",
                                            filterUnits: "userSpaceOnUse",
                                            colorInterpolationFilters: "sRGB",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("feFlood", {
                                                    floodOpacity: "0",
                                                    result: "BackgroundImageFix"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("feColorMatrix", {
                                                    in: "SourceAlpha",
                                                    type: "matrix",
                                                    values: "0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0",
                                                    result: "hardAlpha"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("feOffset", {
                                                    dy: "37.4441"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("feGaussianBlur", {
                                                    stdDeviation: "37.4441"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("feColorMatrix", {
                                                    type: "matrix",
                                                    values: "0 0 0 0 0.178039 0 0 0 0 0.0227451 0 0 0 0 0.0227451 0 0 0 0.8 0"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("feBlend", {
                                                    mode: "normal",
                                                    in2: "BackgroundImageFix",
                                                    result: "effect1_dropShadow_992:132"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("feBlend", {
                                                    mode: "normal",
                                                    in: "SourceGraphic",
                                                    in2: "effect1_dropShadow_992:132",
                                                    result: "shape"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("feColorMatrix", {
                                                    in: "SourceAlpha",
                                                    type: "matrix",
                                                    values: "0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0",
                                                    result: "hardAlpha"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("feOffset", {
                                                    dy: "24.9627"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("feGaussianBlur", {
                                                    stdDeviation: "12.4814"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("feComposite", {
                                                    in2: "hardAlpha",
                                                    operator: "arithmetic",
                                                    k2: "-1",
                                                    k3: "1"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("feColorMatrix", {
                                                    type: "matrix",
                                                    values: "0 0 0 0 1 0 0 0 0 0.168314 0 0 0 0 0.168314 0 0 0 1 0"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("feBlend", {
                                                    mode: "normal",
                                                    in2: "shape",
                                                    result: "effect2_innerShadow_992:132"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("feColorMatrix", {
                                                    in: "SourceAlpha",
                                                    type: "matrix",
                                                    values: "0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0",
                                                    result: "hardAlpha"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("feOffset", {
                                                    dy: "-24.9627"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("feGaussianBlur", {
                                                    stdDeviation: "12.4814"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("feComposite", {
                                                    in2: "hardAlpha",
                                                    operator: "arithmetic",
                                                    k2: "-1",
                                                    k3: "1"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("feColorMatrix", {
                                                    type: "matrix",
                                                    values: "0 0 0 0 0.356078 0 0 0 0 0.0454902 0 0 0 0 0.0454902 0 0 0 1 0"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("feBlend", {
                                                    mode: "normal",
                                                    in2: "effect2_innerShadow_992:132",
                                                    result: "effect3_innerShadow_992:132"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("linearGradient", {
                                            id: "paint0_linear_992:132",
                                            x1: "225",
                                            y1: "38",
                                            x2: "225",
                                            y2: "299.662",
                                            gradientUnits: "userSpaceOnUse",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("stop", {
                                                    "stop-color": "#760F0F"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("stop", {
                                                    offset: "1",
                                                    "stop-color": "#FF2727"
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_framer_motion_.motion.div, {
                        style: {
                            opacity: breakHeart ? "1" : "0",
                            transition: "1s ease-in-out"
                        },
                        className: breakHeart ? "flex w-full items-center justify-center absolute breakHeart" : "flex w-full items-center justify-center absolute",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                                className: "leftHeart",
                                style: {
                                    marginRight: "-136px",
                                    transform: !Once ? "rotateZ(-5deg)" : "rotateZ(0deg)"
                                },
                                height: "300",
                                viewBox: "0 0 316 412",
                                fill: "none",
                                xmlns: "http://www.w3.org/2000/svg",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("g", {
                                        filter: "url(#filter0_dii_1269:82)",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            fillRule: "evenodd",
                                            clipRule: "evenodd",
                                            d: "M224.996 299.654L232 272.492L217 255.992L240.209 227.492L209.783 192.992L240.209 148.992L202.5 116.954L224.996 76.3382L209.783 61.1251C178.95 30.2916 128.959 30.2916 98.1251 61.1251C67.2916 91.9586 67.2916 141.95 98.1251 172.783L113.338 187.996L224.996 299.654Z",
                                            fill: "url(#paint0_linear_1269:82)"
                                        })
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("defs", {
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("filter", {
                                                id: "filter0_dii_1269:82",
                                                x: "0.111763",
                                                y: "0.555882",
                                                width: "314.986",
                                                height: "411.431",
                                                filterUnits: "userSpaceOnUse",
                                                colorInterpolationFilters: "sRGB",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("feFlood", {
                                                        floodOpacity: "0",
                                                        result: "BackgroundImageFix"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("feColorMatrix", {
                                                        in: "SourceAlpha",
                                                        type: "matrix",
                                                        values: "0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0",
                                                        result: "hardAlpha"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("feOffset", {
                                                        dy: "37.4441"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("feGaussianBlur", {
                                                        stdDeviation: "37.4441"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("feColorMatrix", {
                                                        type: "matrix",
                                                        values: "0 0 0 0 0.178039 0 0 0 0 0.0227451 0 0 0 0 0.0227451 0 0 0 0.8 0"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("feBlend", {
                                                        mode: "normal",
                                                        in2: "BackgroundImageFix",
                                                        result: "effect1_dropShadow_1269:82"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("feBlend", {
                                                        mode: "normal",
                                                        in: "SourceGraphic",
                                                        in2: "effect1_dropShadow_1269:82",
                                                        result: "shape"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("feColorMatrix", {
                                                        in: "SourceAlpha",
                                                        type: "matrix",
                                                        values: "0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0",
                                                        result: "hardAlpha"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("feOffset", {
                                                        dy: "24.9627"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("feGaussianBlur", {
                                                        stdDeviation: "12.4814"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("feComposite", {
                                                        in2: "hardAlpha",
                                                        operator: "arithmetic",
                                                        k2: "-1",
                                                        k3: "1"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("feColorMatrix", {
                                                        type: "matrix",
                                                        values: "0 0 0 0 1 0 0 0 0 0.168314 0 0 0 0 0.168314 0 0 0 1 0"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("feBlend", {
                                                        mode: "normal",
                                                        in2: "shape",
                                                        result: "effect2_innerShadow_1269:82"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("feColorMatrix", {
                                                        in: "SourceAlpha",
                                                        type: "matrix",
                                                        values: "0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0",
                                                        result: "hardAlpha"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("feOffset", {
                                                        dy: "-24.9627"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("feGaussianBlur", {
                                                        stdDeviation: "12.4814"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("feComposite", {
                                                        in2: "hardAlpha",
                                                        operator: "arithmetic",
                                                        k2: "-1",
                                                        k3: "1"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("feColorMatrix", {
                                                        type: "matrix",
                                                        values: "0 0 0 0 0.356078 0 0 0 0 0.0454902 0 0 0 0 0.0454902 0 0 0 1 0"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("feBlend", {
                                                        mode: "normal",
                                                        in2: "effect2_innerShadow_1269:82",
                                                        result: "effect3_innerShadow_1269:82"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("linearGradient", {
                                                id: "paint0_linear_1269:82",
                                                x1: "225",
                                                y1: "37.9924",
                                                x2: "225",
                                                y2: "299.654",
                                                gradientUnits: "userSpaceOnUse",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("stop", {
                                                        "stop-color": "#760F0F"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("stop", {
                                                        offset: "1",
                                                        "stop-color": "#FF2727"
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                                className: "rightHeart",
                                height: "300",
                                style: {
                                    transform: !Once ? "rotateZ(5deg)" : "rotateZ(0deg)"
                                },
                                viewBox: "0 0 323 412",
                                fill: "none",
                                xmlns: "http://www.w3.org/2000/svg",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("g", {
                                        filter: "url(#filter0_dii_1269:81)",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "M224.867 61.1328C210.063 46.3215 189.98 38 169.038 38C148.097 38 128.014 46.3215 113.209 61.1328L97.9962 76.3458L75.5 116.962L113.209 149L82.7831 193L113.209 227.5L90 256L105 272.5L97.9962 299.662L209.654 188.004L224.867 172.791C239.678 157.986 248 137.903 248 116.962C248 96.0204 239.678 75.9372 224.867 61.1328Z",
                                            fill: "url(#paint0_linear_1269:81)"
                                        })
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("defs", {
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("filter", {
                                                id: "filter0_dii_1269:81",
                                                x: "0.611763",
                                                y: "0.555882",
                                                width: "322.276",
                                                height: "411.438",
                                                filterUnits: "userSpaceOnUse",
                                                colorInterpolationFilters: "sRGB",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("feFlood", {
                                                        floodOpacity: "0",
                                                        result: "BackgroundImageFix"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("feColorMatrix", {
                                                        in: "SourceAlpha",
                                                        type: "matrix",
                                                        values: "0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0",
                                                        result: "hardAlpha"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("feOffset", {
                                                        dy: "37.4441"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("feGaussianBlur", {
                                                        stdDeviation: "37.4441"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("feColorMatrix", {
                                                        type: "matrix",
                                                        values: "0 0 0 0 0.178039 0 0 0 0 0.0227451 0 0 0 0 0.0227451 0 0 0 0.8 0"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("feBlend", {
                                                        mode: "normal",
                                                        in2: "BackgroundImageFix",
                                                        result: "effect1_dropShadow_1269:81"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("feBlend", {
                                                        mode: "normal",
                                                        in: "SourceGraphic",
                                                        in2: "effect1_dropShadow_1269:81",
                                                        result: "shape"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("feColorMatrix", {
                                                        in: "SourceAlpha",
                                                        type: "matrix",
                                                        values: "0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0",
                                                        result: "hardAlpha"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("feOffset", {
                                                        dy: "24.9627"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("feGaussianBlur", {
                                                        stdDeviation: "12.4814"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("feComposite", {
                                                        in2: "hardAlpha",
                                                        operator: "arithmetic",
                                                        k2: "-1",
                                                        k3: "1"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("feColorMatrix", {
                                                        type: "matrix",
                                                        values: "0 0 0 0 1 0 0 0 0 0.168314 0 0 0 0 0.168314 0 0 0 1 0"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("feBlend", {
                                                        mode: "normal",
                                                        in2: "shape",
                                                        result: "effect2_innerShadow_1269:81"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("feColorMatrix", {
                                                        in: "SourceAlpha",
                                                        type: "matrix",
                                                        values: "0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0",
                                                        result: "hardAlpha"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("feOffset", {
                                                        dy: "-24.9627"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("feGaussianBlur", {
                                                        stdDeviation: "12.4814"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("feComposite", {
                                                        in2: "hardAlpha",
                                                        operator: "arithmetic",
                                                        k2: "-1",
                                                        k3: "1"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("feColorMatrix", {
                                                        type: "matrix",
                                                        values: "0 0 0 0 0.356078 0 0 0 0 0.0454902 0 0 0 0 0.0454902 0 0 0 1 0"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("feBlend", {
                                                        mode: "normal",
                                                        in2: "effect2_innerShadow_1269:81",
                                                        result: "effect3_innerShadow_1269:81"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("linearGradient", {
                                                id: "paint0_linear_1269:81",
                                                x1: "98",
                                                y1: "38",
                                                x2: "98",
                                                y2: "299.662",
                                                gradientUnits: "userSpaceOnUse",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("stop", {
                                                        "stop-color": "#760F0F"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("stop", {
                                                        offset: "1",
                                                        "stop-color": "#FF2727"
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "pb-6 -mt-12 text-center text-2xl md:text-4xl font-bold tracking-widest uppercase",
                children: /*#__PURE__*/ jsx_runtime_.jsx((external_typewriter_effect_default()), {
                    options: {
                        cursor: "",
                        delay: 100
                    },
                    onInit: (typewriter)=>{
                        typewriter.pauseFor(5500).typeString('<span class="text-stroke-sm">follow</span> to <span class="text-stroke-sm">heal</span> my broken heart').callFunction(()=>{
                            setShowSocial(true);
                        }).start();
                    }
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: showSocial ? "transform md:scale-150 md:p-6 transition duration-1000 opacity-1" : "transform md:scale-150 md:p-6 transition duration-1000 opacity-0",
                children: /*#__PURE__*/ jsx_runtime_.jsx(SocialTray/* default */.Z, {
                    social: false,
                    setOnce: setOnce
                })
            })
        ]
    }));
};
/* harmony default export */ const components_Easter = (Easter);

// EXTERNAL MODULE: external "react-locomotive-scroll"
var external_react_locomotive_scroll_ = __webpack_require__(2966);
;// CONCATENATED MODULE: ./components/Footer.jsx






const Footer = ()=>{
    const { 0: EasterEgg , 1: setEasterEgg  } = (0,external_react_.useState)(false);
    const { 0: Once , 1: setOnce  } = (0,external_react_.useState)(true);
    const { scroll  } = (0,external_react_locomotive_scroll_.useLocomotiveScroll)();
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(external_framer_motion_.AnimatePresence, {
                exitBeforeEnter: true,
                initial: false,
                children: EasterEgg && /*#__PURE__*/ jsx_runtime_.jsx(components_Easter, {
                    setEasterEgg: setEasterEgg,
                    setOnce: setOnce,
                    Once: Once
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                "data-scroll-section": true,
                className: "flex items-center md:justify-between justify-center pt-4 pb-2",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "md:flex hidden items-center",
                    onClick: ()=>scroll.scrollTo("top", {
                            duration: 1
                        })
                    ,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "transform rotate-180",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((ScrollArrow_default()), {
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "text-sm font-medium tracking-widest leading-snug text-gray-100 uppercase",
                            children: "scroll to top and live again"
                        })
                    ]
                })
            })
        ]
    }));
};
/* harmony default export */ const components_Footer = (Footer);

// EXTERNAL MODULE: external "classnames"
var external_classnames_ = __webpack_require__(9003);
var external_classnames_default = /*#__PURE__*/__webpack_require__.n(external_classnames_);
;// CONCATENATED MODULE: ./components/Cursor.jsx




const Cursor = ()=>{
    const { 0: position , 1: setPosition  } = (0,external_react_.useState)({
        x: 0,
        y: 0
    });
    const { 0: hidden , 1: setHidden  } = (0,external_react_.useState)(true);
    const { 0: clicked , 1: setClicked  } = (0,external_react_.useState)(false);
    const { 0: linkHovered , 1: setLinkHovered  } = (0,external_react_.useState)(false);
    const router = (0,router_.useRouter)();
    (0,external_react_.useEffect)(()=>{
        addEventListeners();
        handleLinkHoverEvents();
        return ()=>removeEventListeners()
        ;
    }, [
        router
    ]);
    const handleLinkHoverEvents = ()=>{
        document.querySelectorAll("a").forEach((el)=>{
            el.addEventListener("mouseover", ()=>setLinkHovered(true)
            );
            el.addEventListener("mouseout", ()=>setLinkHovered(false)
            );
        });
    };
    const addEventListeners = ()=>{
        document.addEventListener("mousemove", onMouseMove);
        document.addEventListener("mouseenter", onMouseEnter);
        document.addEventListener("mouseleave", onMouseLeave);
        document.addEventListener("mousedown", onMouseDown);
        document.addEventListener("mouseup", onMouseUp);
    };
    const removeEventListeners = ()=>{
        document.removeEventListener("mousemove", onMouseMove);
        document.removeEventListener("mouseenter", onMouseEnter);
        document.removeEventListener("mouseleave", onMouseLeave);
        document.removeEventListener("mousedown", onMouseDown);
        document.removeEventListener("mouseup", onMouseUp);
    };
    const onMouseLeave = ()=>{
        setHidden(true);
    };
    const onMouseEnter = ()=>{
        setHidden(false);
    };
    const onMouseMove = (e)=>{
        setHidden(false);
        setPosition({
            x: e.clientX,
            y: e.clientY
        });
    };
    const onMouseDown = ()=>{
        setClicked(true);
    };
    const onMouseUp = ()=>{
        setClicked(false);
    };
    const cursorClasses = external_classnames_default()("cursor", {
        "cursor--clicked": clicked,
        "cursor--hidden": hidden,
        "cursor--link-hovered": linkHovered
    });
    const isMobile = ()=>{
        const ua = navigator.userAgent;
        return /Android|Mobi/i.test(ua);
    };
    if (typeof navigator !== "undefined" && isMobile()) return null;
    return(/*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: cursorClasses,
        style: {
            left: `${position.x}px`,
            top: `${position.y}px`
        }
    }));
};
/* harmony default export */ const components_Cursor = (Cursor);

;// CONCATENATED MODULE: ./components/Layout.jsx








const Layout = (props)=>{
    const containerRef = (0,external_react_.useRef)(null);
    const { pathname  } = (0,router_.useRouter)();
    const { scroll: scroll1  } = (0,external_react_locomotive_scroll_.useLocomotiveScroll)();
    const path = pathname.split("?")[0];
    return(// <div>
    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_framer_motion_.AnimateSharedLayout, {
        type: "crossfade",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(external_react_locomotive_scroll_.LocomotiveScrollProvider, {
                options: {
                    smooth: true
                },
                watch: [
                    path
                ],
                location: path,
                containerRef: containerRef,
                onLocationChange: (scroll)=>scroll.scrollTo(0, {
                        duration: 0,
                        disableLerp: true
                    })
                ,
                onUpdate: ()=>console.log("Updated, but not on location change!")
                ,
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    "data-scroll-container": true,
                    className: "w-screen",
                    ref: containerRef,
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "Layout md:px-4 container mx-auto bg-dark antialiased text-light w-screen h-full",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(components_Navbar, {
                            }),
                            props.children,
                            /*#__PURE__*/ jsx_runtime_.jsx(components_Footer, {
                                scroll: scroll1
                            })
                        ]
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(components_Cursor, {
            })
        ]
    }));
};
/* harmony default export */ const components_Layout = (Layout);


/***/ })

};
;