exports.id = 259;
exports.ids = [259];
exports.modules = {

/***/ 1259:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _assets_LinkedinIcon_svg__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7708);
/* harmony import */ var _assets_LinkedinIcon_svg__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_assets_LinkedinIcon_svg__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _assets_GmailIcon_svg__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1773);
/* harmony import */ var _assets_GmailIcon_svg__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_assets_GmailIcon_svg__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _assets_TwitterIcon_svg__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8675);
/* harmony import */ var _assets_TwitterIcon_svg__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_assets_TwitterIcon_svg__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _assets_InstagramIcon_svg__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3402);
/* harmony import */ var _assets_InstagramIcon_svg__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_assets_InstagramIcon_svg__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _assets_GithubIcon_svg__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3459);
/* harmony import */ var _assets_GithubIcon_svg__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_assets_GithubIcon_svg__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _assets_SpotifyIcon_svg__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6141);
/* harmony import */ var _assets_SpotifyIcon_svg__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_assets_SpotifyIcon_svg__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _assets_DribbbleIcon_svg__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4037);
/* harmony import */ var _assets_DribbbleIcon_svg__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_assets_DribbbleIcon_svg__WEBPACK_IMPORTED_MODULE_8__);









const SocialTray = ({ social =true , setOnce =false  })=>{
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "flex items-center space-x-4 w-full justify-between",
        children: social ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                    onClick: ()=>setOnce && setOnce(true)
                    ,
                    rel: "noreferrer",
                    href: "#",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_assets_GmailIcon_svg__WEBPACK_IMPORTED_MODULE_3___default()), {
                        className: "h-10 w-10"
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                    onClick: ()=>setOnce && setOnce(true)
                    ,
                    rel: "noreferrer",
                    href: "#",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_assets_TwitterIcon_svg__WEBPACK_IMPORTED_MODULE_4___default()), {
                        className: "h-10 w-10"
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                    onClick: ()=>setOnce && setOnce(true)
                    ,
                    rel: "noreferrer",
                    target: "_blank",
                    href: "https://www.instagram.com/befas.official/",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_assets_InstagramIcon_svg__WEBPACK_IMPORTED_MODULE_5___default()), {
                        className: "h-10 w-10"
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                    onClick: ()=>setOnce && setOnce(true)
                    ,
                    rel: "noreferrer",
                    href: "#",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_assets_GithubIcon_svg__WEBPACK_IMPORTED_MODULE_6___default()), {
                        className: "h-10 w-10"
                    })
                })
            ]
        }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                    onClick: ()=>setOnce && setOnce(true)
                    ,
                    rel: "noreferrer",
                    target: "_blank",
                    href: "https://twitter.com/techakhil_me",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_assets_TwitterIcon_svg__WEBPACK_IMPORTED_MODULE_4___default()), {
                        className: "h-10 w-10"
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                    onClick: ()=>setOnce && setOnce(true)
                    ,
                    rel: "noreferrer",
                    target: "_blank",
                    href: "https://www.instagram.com/techakhil.me/",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_assets_InstagramIcon_svg__WEBPACK_IMPORTED_MODULE_5___default()), {
                        className: "h-10 w-10"
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                    onClick: ()=>setOnce && setOnce(true)
                    ,
                    rel: "noreferrer",
                    target: "_blank",
                    href: "https://github.com/techakhil-me",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_assets_GithubIcon_svg__WEBPACK_IMPORTED_MODULE_6___default()), {
                        className: "h-10 w-10"
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                    onClick: ()=>setOnce && setOnce(true)
                    ,
                    rel: "noreferrer",
                    target: "_blank",
                    href: "https://open.spotify.com/user/316xdrzidluzl4jgxpymgiry6fhi?si=e2b5df4a3e3e4674",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_assets_SpotifyIcon_svg__WEBPACK_IMPORTED_MODULE_7___default()), {
                        className: "h-10 w-10"
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                    onClick: ()=>setOnce && setOnce(true)
                    ,
                    rel: "noreferrer",
                    target: "_blank",
                    href: "https://dribbble.com/techakhil",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_assets_DribbbleIcon_svg__WEBPACK_IMPORTED_MODULE_8___default()), {
                        className: "h-10 w-10"
                    })
                })
            ]
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SocialTray);


/***/ }),

/***/ 4037:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var React = __webpack_require__(6689);

function DribbbleIcon (props) {
    return React.createElement("svg",props,React.createElement("path",{"d":"M41.0833 39.925C41.2208 39.875 41.3667 39.8375 41.5125 39.7958C41.1429 38.9763 40.7553 38.165 40.35 37.3625C32.5167 39.6833 25.0167 39.7042 23.6792 39.6833C23.6667 39.7875 23.6667 39.8958 23.6667 40C23.6667 43.9375 25.0833 47.7208 27.6583 50.6917C28.5167 49.3083 33.0667 42.5208 41.0833 39.925ZM30.0958 52.9708C32.3621 54.7076 35.0447 55.8187 37.8753 56.1931C40.7059 56.5675 43.5851 56.192 46.225 55.1042C45.4596 50.9493 44.3131 46.8737 42.8 42.9292C33.9625 46.0542 30.625 51.9375 30.0958 52.9708V52.9708ZM50.6458 27.6125C48.7199 25.9582 46.4349 24.7756 43.9721 24.1586C41.5094 23.5417 38.9367 23.5073 36.4583 24.0583C38.6329 27.0127 40.6107 30.1069 42.3792 33.3208C47.725 31.2667 50.1417 28.3042 50.6458 27.6125V27.6125ZM38.7708 34.4333C36.9749 31.2842 35.0067 28.2365 32.875 25.3042C30.6743 26.3765 28.7413 27.9277 27.2179 29.844C25.6945 31.7603 24.6192 33.9933 24.0708 36.3792H24.1417C25.8333 36.3792 31.8458 36.2417 38.7708 34.4333ZM46.3083 42.0667C48.2458 47.4542 49.1375 51.9292 49.3917 53.3625C52.9427 50.8589 55.3541 47.0477 56.0958 42.7667C53.9381 42.1539 51.7056 41.844 49.4625 41.8458C48.3875 41.8458 47.325 41.9208 46.3083 42.0667V42.0667ZM40 0C17.9083 0 0 17.9083 0 40C0 62.0917 17.9083 80 40 80C62.0917 80 80 62.0917 80 40C80 17.9083 62.0917 0 40 0ZM40 59.5708C34.8101 59.5664 29.8339 57.5033 26.1633 53.8343C22.4926 50.1653 20.4275 45.1899 20.4208 40C20.4252 34.8086 22.4895 29.8312 26.1603 26.1603C29.8312 22.4895 34.8086 20.4252 40 20.4208C45.1903 20.4275 50.1661 22.4925 53.8358 26.163C57.5055 29.8335 59.5695 34.8097 59.575 40C59.5695 45.1895 57.5052 50.1649 53.8353 53.834C50.1653 57.5032 45.1895 59.5664 40 59.5708ZM43.8417 36.1417C44.2042 36.8917 44.5417 37.6292 44.85 38.3542L45.1458 39.0625C46.3 38.925 47.5333 38.8583 48.8208 38.8583C51.3391 38.8634 53.8513 39.1033 56.325 39.575C56.2299 36.0261 54.984 32.6042 52.775 29.825C52.1083 30.6833 49.3667 33.8375 43.8417 36.1417V36.1417Z","fill":"#F7F7F7"}));
}

DribbbleIcon.defaultProps = {"viewBox":"0 0 80 80","fill":"none"};

module.exports = DribbbleIcon;

DribbbleIcon.default = DribbbleIcon;


/***/ }),

/***/ 3459:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var React = __webpack_require__(6689);

function GithubIcon (props) {
    return React.createElement("svg",props,React.createElement("path",{"fillRule":"evenodd","clipRule":"evenodd","d":"M40.6665 80C62.7579 80 80.6665 62.0914 80.6665 40C80.6665 17.9086 62.7579 -3.27136e-06 40.6665 -3.27136e-06C18.5752 -3.27136e-06 0.66655 17.9086 0.66655 40C0.66655 62.0914 18.5752 80 40.6665 80ZM33.1655 64.4804C33.1655 65.2878 32.603 66.2106 31.103 65.9414C34.2405 69.1539 42.443 73.6514 50.153 65.9414C48.653 66.249 48.0905 65.2878 48.0905 64.4804C48.0905 64.1333 48.0947 63.5326 48.1003 62.7328C48.1114 61.1408 48.128 58.7602 48.128 56.0218C48.128 53.1381 47.1905 51.2926 46.103 50.3314C52.778 49.5624 59.7905 46.9479 59.7905 35.1442C59.7905 31.7608 58.628 29.0309 56.7155 26.8778C57.0155 26.1088 58.0655 22.9561 56.4155 18.7267C56.4155 18.7267 53.903 17.8809 48.1655 21.8795C45.7655 21.1874 43.2155 20.8414 40.6655 20.8414C38.1155 20.8414 35.5655 21.1874 33.1655 21.8795C27.428 17.9193 24.9155 18.7267 24.9155 18.7267C23.2655 22.9561 24.3155 26.1088 24.6155 26.8778C22.703 29.0309 21.5405 31.7992 21.5405 35.1442C21.5405 46.9095 28.5155 49.5624 35.1905 50.3314C34.328 51.1004 33.5405 52.4461 33.278 54.4454C31.553 55.2528 27.2405 56.5601 24.5405 51.9078C23.978 50.985 22.2905 48.7166 19.928 48.755C17.4155 48.7935 18.9155 50.2161 19.9655 50.7928C21.2405 51.5233 22.703 54.2532 23.0405 55.1375C23.6405 56.8677 25.5905 60.1742 33.128 58.7516C33.128 60.4325 33.144 62.0479 33.1551 63.1706C33.161 63.7684 33.1655 64.2265 33.1655 64.4804Z","fill":"#F7F7F7"}));
}

GithubIcon.defaultProps = {"width":"81","height":"80","viewBox":"0 0 81 80","fill":"none"};

module.exports = GithubIcon;

GithubIcon.default = GithubIcon;


/***/ }),

/***/ 1773:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var React = __webpack_require__(6689);

function GmailIcon (props) {
    return React.createElement("svg",props,React.createElement("path",{"fillRule":"evenodd","clipRule":"evenodd","d":"M40.3333 0C18.2419 0 0.333252 17.9086 0.333252 40C0.333252 62.0914 18.2419 80 40.3333 80C62.4246 80 80.3333 62.0914 80.3333 40C80.3333 17.9086 62.4246 0 40.3333 0ZM16.9999 26C16.9999 23.41 19.0766 21.3333 21.6666 21.3333H58.9999C60.2376 21.3333 61.4246 21.825 62.2998 22.7002C63.1749 23.5753 63.6666 24.7623 63.6666 26V54C63.6666 55.2377 63.1749 56.4247 62.2998 57.2998C61.4246 58.175 60.2376 58.6667 58.9999 58.6667H21.6666C20.4289 58.6667 19.2419 58.175 18.3668 57.2998C17.4916 56.4247 16.9999 55.2377 16.9999 54V26ZM58.9999 54H54.3333V33.5833L40.3333 42.3333L26.3333 33.5833V54H21.6666V26H24.4666L40.3333 35.9167L56.1999 26H58.9999V54Z","fill":"#F7F7F7"}));
}

GmailIcon.defaultProps = {"width":"81","height":"80","viewBox":"0 0 81 80","fill":"none"};

module.exports = GmailIcon;

GmailIcon.default = GmailIcon;


/***/ }),

/***/ 3402:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var React = __webpack_require__(6689);

function InstagramIcon (props) {
    return React.createElement("svg",props,React.createElement("path",{"fillRule":"evenodd","clipRule":"evenodd","d":"M40 0C17.9086 0 0 17.9086 0 40C0 62.0914 17.9086 80 40 80C62.0914 80 80 62.0914 80 40C80 17.9086 62.0914 0 40 0ZM40 18C34.024 18 33.276 18.024 30.93 18.132C28.59 18.24 26.988 18.612 25.588 19.154C24.1209 19.7069 22.7921 20.573 21.694 21.692C20.5742 22.7906 19.7074 24.1202 19.154 25.588C18.612 26.988 18.238 28.588 18.132 30.932C18.026 33.276 18 34.024 18 40C18 45.974 18.024 46.722 18.132 49.072C18.24 51.412 18.612 53.012 19.154 54.412C19.7066 55.8798 20.5728 57.2093 21.692 58.308C22.7916 59.4265 24.1218 60.2919 25.59 60.844C26.99 61.388 28.59 61.762 30.93 61.868C33.276 61.974 34.024 62 40 62C45.976 62 46.724 61.976 49.072 61.868C51.412 61.76 53.012 61.388 54.412 60.844C55.878 60.292 57.208 59.428 58.308 58.308C59.4266 57.2084 60.292 55.8782 60.844 54.41C61.388 53.01 61.762 51.41 61.868 49.07C61.974 46.724 62 45.976 62 40C62 34.026 61.976 33.278 61.868 30.928C61.76 28.588 61.388 26.988 60.844 25.588C60.292 24.12 59.428 22.792 58.308 21.694C57.208 20.574 55.878 19.708 54.412 19.154C53.012 18.612 51.412 18.238 49.068 18.132C46.724 18.026 45.976 18 40 18ZM48.89 22.092C46.57 21.986 45.874 21.964 40 21.964C34.126 21.964 33.43 21.986 31.11 22.092C28.964 22.19 27.8 22.548 27.024 22.85C25.998 23.25 25.264 23.724 24.494 24.494C23.7641 25.2041 23.2024 26.0686 22.85 27.024C22.548 27.8 22.19 28.964 22.092 31.11C21.986 33.43 21.964 34.126 21.964 40C21.964 45.874 21.986 46.57 22.092 48.89C22.19 51.036 22.548 52.2 22.85 52.976C23.202 53.93 23.764 54.796 24.494 55.506C25.204 56.236 26.07 56.798 27.024 57.15C27.8 57.452 28.964 57.81 31.11 57.908C33.43 58.014 34.124 58.036 40 58.036C45.876 58.036 46.57 58.014 48.89 57.908C51.036 57.81 52.2 57.452 52.976 57.15C54.002 56.75 54.736 56.276 55.506 55.506C56.236 54.796 56.798 53.93 57.15 52.976C57.452 52.2 57.81 51.036 57.908 48.89C58.014 46.57 58.036 45.874 58.036 40C58.036 34.126 58.014 33.43 57.908 31.11C57.81 28.964 57.452 27.8 57.15 27.024C56.75 25.998 56.276 25.264 55.506 24.494C54.7959 23.7641 53.9314 23.2024 52.976 22.85C52.2 22.548 51.036 22.19 48.89 22.092ZM32.004 32.004C33.054 30.9539 34.3006 30.121 35.6726 29.5527C37.0446 28.9844 38.515 28.6919 40 28.6919C41.485 28.6919 42.9554 28.9844 44.3274 29.5527C45.6994 30.121 46.946 30.9539 47.996 32.004C49.0461 33.054 49.879 34.3006 50.4473 35.6726C51.0156 37.0446 51.3081 38.515 51.3081 40C51.3081 41.485 51.0156 42.9554 50.4473 44.3274C49.879 45.6994 49.0461 46.946 47.996 47.996C45.8753 50.1167 42.9991 51.3081 40 51.3081C37.0009 51.3081 34.1247 50.1167 32.004 47.996C29.8833 45.8753 28.6919 42.9991 28.6919 40C28.6919 37.0009 29.8833 34.1247 32.004 32.004ZM42.1339 47.0314C40.5068 47.5234 38.7593 47.4353 37.19 46.782C36.1877 46.3664 35.2899 45.7337 34.5614 44.9294C33.833 44.1252 33.2919 43.1695 32.9771 42.131C32.6623 41.0926 32.5817 39.9973 32.741 38.9239C32.9004 37.8506 33.2957 36.8259 33.8986 35.9237C34.5015 35.0215 35.2969 34.2642 36.2276 33.7063C37.1583 33.1484 38.2011 32.8037 39.281 32.6972C40.3609 32.5907 41.4509 32.725 42.4727 33.0903C43.4944 33.4556 44.4225 34.043 45.19 34.81C46.394 36.0099 47.1441 37.5907 47.3121 39.2822C47.4801 40.9737 47.0557 42.6711 46.1112 44.0845C45.1668 45.4978 43.761 46.5395 42.1339 47.0314ZM54.4286 29.5079C54.2845 29.8354 54.0762 30.1305 53.816 30.376C53.3099 30.8534 52.6378 31.1147 51.9421 31.1046C51.2465 31.0945 50.5822 30.8136 50.0903 30.3217C49.5984 29.8298 49.3175 29.1655 49.3074 28.4699C49.2973 27.7742 49.5586 27.1021 50.036 26.596C50.2815 26.3358 50.5766 26.1275 50.9041 25.9834C51.2315 25.8393 51.5845 25.7624 51.9421 25.7572C52.2998 25.752 52.6549 25.8186 52.9864 25.953C53.3179 26.0875 53.619 26.2871 53.8719 26.5401C54.1249 26.793 54.3245 27.0941 54.459 27.4256C54.5934 27.7571 54.66 28.1122 54.6548 28.4699C54.6496 28.8275 54.5727 29.1805 54.4286 29.5079Z","fill":"#F7F7F7"}));
}

InstagramIcon.defaultProps = {"width":"80","height":"80","viewBox":"0 0 80 80","fill":"none"};

module.exports = InstagramIcon;

InstagramIcon.default = InstagramIcon;


/***/ }),

/***/ 7708:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var React = __webpack_require__(6689);

function LinkedinIcon (props) {
    return React.createElement("svg",props,React.createElement("path",{"d":"M40 0C17.9083 0 0 17.9083 0 40C0 62.0917 17.9083 80 40 80C62.0917 80 80 62.0917 80 40C80 17.9083 62.0917 0 40 0ZM30.2083 56.5792H22.1083V30.5125H30.2083V56.5792ZM26.1083 27.3125C23.55 27.3125 21.8958 25.5 21.8958 23.2583C21.8958 20.9708 23.6 19.2125 26.2125 19.2125C28.825 19.2125 30.425 20.9708 30.475 23.2583C30.475 25.5 28.825 27.3125 26.1083 27.3125ZM59.7917 56.5792H51.6917V42.1333C51.6917 38.7708 50.5167 36.4875 47.5875 36.4875C45.35 36.4875 44.0208 38.0333 43.4333 39.5208C43.2167 40.05 43.1625 40.8 43.1625 41.5458V56.575H35.0583V38.825C35.0583 35.5708 34.9542 32.85 34.8458 30.5083H41.8833L42.2542 34.1292H42.4167C43.4833 32.4292 46.0958 29.9208 50.4667 29.9208C55.7958 29.9208 59.7917 33.4917 59.7917 41.1667V56.5792V56.5792Z","fill":"#F7F7F7"}));
}

LinkedinIcon.defaultProps = {"width":"80","height":"80","viewBox":"0 0 80 80","fill":"none"};

module.exports = LinkedinIcon;

LinkedinIcon.default = LinkedinIcon;


/***/ }),

/***/ 6141:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var React = __webpack_require__(6689);

function SpotifyIcon (props) {
    return React.createElement("svg",props,React.createElement("path",{"d":"M40.3333 0C18.2416 0 0.333252 17.9083 0.333252 40C0.333252 62.0917 18.2416 80 40.3333 80C62.4249 80 80.3333 62.0917 80.3333 40C80.3333 17.9083 62.4249 0 40.3333 0ZM52.6833 55.9875C52.0666 55.9875 51.6416 55.7542 51.1874 55.4792C46.9666 52.925 41.7374 51.5833 36.0708 51.5833C33.1791 51.5833 30.0583 51.925 26.7958 52.5917L26.3999 52.6917C25.9833 52.7917 25.5624 52.9 25.2374 52.9C24.9297 52.9045 24.6243 52.8473 24.339 52.732C24.0537 52.6167 23.7943 52.4455 23.5761 52.2285C23.358 52.0115 23.1854 51.7531 23.0685 51.4684C22.9517 51.1837 22.8929 50.8785 22.8958 50.5708C22.8958 49.2458 23.6458 48.3083 24.8916 48.0708C28.5618 47.2102 32.3177 46.7685 36.0874 46.7542C42.6708 46.7542 48.5624 48.275 53.5916 51.2958C54.4583 51.8 54.9999 52.3792 54.9999 53.6667C54.9999 54.2815 54.756 54.8712 54.3216 55.3063C53.8873 55.7414 53.2981 55.9864 52.6833 55.9875V55.9875ZM55.9249 46.8917C55.1874 46.8917 54.7083 46.6125 54.2791 46.3625C46.6749 41.8458 35.3332 40.35 26.0082 42.8333C25.8663 42.8754 25.7246 42.9185 25.5833 42.9625C25.2333 43.075 24.8999 43.1833 24.4416 43.1833C23.7019 43.18 22.9938 42.8833 22.4727 42.3583C21.9516 41.8333 21.6602 41.123 21.6624 40.3833C21.6624 38.8958 22.4374 37.8542 23.8458 37.4583C27.6905 36.3441 31.6763 35.7925 35.6791 35.8208C43.5374 35.8208 51.1541 37.7917 57.1208 41.3625C58.2083 41.9792 58.6999 42.8333 58.6999 44.1042C58.6999 45.6458 57.4541 46.8917 55.9249 46.8917V46.8917ZM59.6041 36.525C58.9822 36.5269 58.373 36.3489 57.8499 36.0125C52.6874 32.9125 44.6374 31.0708 36.2916 31.0708C31.9458 31.0708 27.9999 31.55 24.5541 32.4792C24.4377 32.5086 24.3224 32.542 24.2083 32.5792C23.7887 32.7216 23.3509 32.803 22.9083 32.8208C22.4762 32.8225 22.0481 32.7381 21.649 32.5724C21.25 32.4067 20.888 32.1631 20.5842 31.8558C20.2804 31.5485 20.0409 31.1837 19.8798 30.7828C19.7187 30.3819 19.6391 29.9529 19.6458 29.5208C19.6458 27.9125 20.5499 26.6833 22.0583 26.2375C26.2166 25.0083 31.0083 24.3917 36.2874 24.3917C45.7916 24.3917 54.8416 26.5 61.1083 30.1875C62.2916 30.8542 62.8708 31.8708 62.8708 33.2792C62.8736 33.708 62.7908 34.133 62.6274 34.5294C62.464 34.9259 62.2231 35.2857 61.9189 35.588C61.6148 35.8902 61.2534 36.1288 60.8559 36.2896C60.4584 36.4505 60.0328 36.5306 59.6041 36.525V36.525Z","fill":"#F7F7F7"}));
}

SpotifyIcon.defaultProps = {"width":"81","height":"80","viewBox":"0 0 81 80","fill":"none"};

module.exports = SpotifyIcon;

SpotifyIcon.default = SpotifyIcon;


/***/ }),

/***/ 8675:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var React = __webpack_require__(6689);

function TwitterIcon (props) {
    return React.createElement("svg",props,React.createElement("path",{"d":"M40.6667 0C18.5751 0 0.666748 17.9083 0.666748 40C0.666748 62.0917 18.5751 80 40.6667 80C62.7584 80 80.6667 62.0917 80.6667 40C80.6667 17.9083 62.7584 0 40.6667 0ZM56.9376 32.7667C56.9542 33.1083 56.9584 33.45 56.9584 33.7833C56.9584 44.2 49.0376 56.2042 34.5459 56.2042C30.2638 56.2113 26.0708 54.9814 22.4709 52.6625C23.0834 52.7375 23.7126 52.7667 24.3501 52.7667C28.0417 52.7667 31.4376 51.5125 34.1334 49.3958C32.4906 49.3636 30.8987 48.8196 29.5797 47.8397C28.2607 46.8597 27.2803 45.4927 26.7751 43.9292C27.9549 44.1535 29.1703 44.1065 30.3292 43.7917C28.5461 43.4311 26.9426 42.4649 25.7905 41.0569C24.6385 39.649 24.0089 37.8859 24.0084 36.0667V35.9708C25.0709 36.5583 26.2876 36.9167 27.5792 36.9583C25.9076 35.8455 24.7242 34.1361 24.2711 32.1797C23.818 30.2233 24.1295 28.1677 25.1417 26.4333C27.1207 28.8667 29.5887 30.8573 32.3858 32.2763C35.1829 33.6953 38.2468 34.5111 41.3792 34.6708C40.981 32.9805 41.1524 31.2059 41.8668 29.6229C42.5812 28.04 43.7985 26.7375 45.3295 25.9178C46.8606 25.0981 48.6195 24.8072 50.333 25.0903C52.0464 25.3734 53.6183 26.2147 54.8042 27.4833C56.5675 27.1345 58.2583 26.4877 59.8042 25.5708C59.2166 27.3964 57.9862 28.9466 56.3417 29.9333C57.9036 29.7452 59.4287 29.3253 60.8667 28.6875C59.8104 30.2704 58.4798 31.6518 56.9376 32.7667V32.7667Z","fill":"#F7F7F7"}));
}

TwitterIcon.defaultProps = {"width":"80","height":"80","viewBox":"0 0 80 80","fill":"none"};

module.exports = TwitterIcon;

TwitterIcon.default = TwitterIcon;


/***/ })

};
;